package dto;

import java.util.List;

public class SinhVienDTO {
    private int id;
    private String name;
    private String lopHoc;
    private List<DiemThiDTO> diemThis;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLopHoc() {
        return lopHoc;
    }

    public void setLopHoc(String lopHoc) {
        this.lopHoc = lopHoc;
    }

    public List<DiemThiDTO> getDiemThis() {
        return diemThis;
    }

    public void setDiemThis(List<DiemThiDTO> diemThis) {
        this.diemThis = diemThis;
    }
    
    
}
