package aaaaaaaa;

import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import model.LopHoc;

@Stateless
@LocalBean
public class ClassFinder {

    @PersistenceContext
    private EntityManager em;

    public List<LopHoc> findAll() {
        return em.createQuery("select a from LopHoc a").getResultList();
    }
}
