package aaaaaaaa;

import dto.DiemThiDTO;
import dto.SinhVienDTO;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import model.Diemthi;
import model.LopHoc;
import model.SinhVien;

@Stateless
@LocalBean
public class SinhVienFinder {

    @PersistenceContext
    private EntityManager em;

    public String findSinhVienNameById(int idSinhVien) {
        SinhVien sv = em.find(SinhVien.class, idSinhVien);
        return sv.getName();
    }

    public List<SinhVienDTO> findAll() {
        List<SinhVienDTO> response = new ArrayList<>();

        List<SinhVien> sinhViens = em.createQuery("select a from SinhVien a", SinhVien.class)
                .getResultList();

//        for (SinhVien sv : sinhViens) {
//            SinhVienDTO dto = new SinhVienDTO();
//
//            LopHoc lopHoc = sv.getLopHoc();
//
//            dto.setId(sv.getId());
//            dto.setName(sv.getName());
//            dto.setLopHoc(lopHoc.getName());
//
//            List<DiemThiDTO> diemThis = new ArrayList<>();
//
//            Collection<Diemthi> diemThiList = sv.getDiemThis();
//            for (Diemthi dt : diemThiList) {
//                DiemThiDTO dtDto =new DiemThiDTO();
//             
//                dtDto.setDiemThi(dt.getMark());
//                dtDto.setMonHoc(dt.getMonHoc().getName());
//                
//                diemThis.add(dtDto);
//            }
//
//            dto.setDiemThis(diemThis);
//
//            response.add(dto);
//        }
        for (SinhVien sv : sinhViens) {
            SinhVienDTO dto = this.toSinhVienDTO(sv);
            response.add(dto);
        }
        return response;
    }

    private SinhVienDTO toSinhVienDTO(SinhVien sv) {
        SinhVienDTO dto = new SinhVienDTO();

        dto.setId(sv.getId());
        dto.setName(sv.getName());
        dto.setLopHoc(sv.getLopHoc().getName());

        List<DiemThiDTO> diemThis = this.extractDiemThis(sv);
        dto.setDiemThis(diemThis);

        return dto;
    }

    private List<DiemThiDTO> extractDiemThis(SinhVien sv) {
        List<DiemThiDTO> diemThis = new ArrayList<>();

        Collection<Diemthi> diemThiList = sv.getDiemThis();
        for (Diemthi dt : diemThiList) {
            DiemThiDTO dtDto = new DiemThiDTO();

            dtDto.setDiemThi(dt.getMark());
            dtDto.setMonHoc(dt.getMonHoc().getName());

            diemThis.add(dtDto);
        }

        return diemThis;
    }
}
