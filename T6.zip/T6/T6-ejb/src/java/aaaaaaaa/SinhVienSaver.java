package aaaaaaaa;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import model.LopHoc;
import model.SinhVien;

@Stateless
@LocalBean
public class SinhVienSaver {

    @PersistenceContext
    private EntityManager em;

    public void chuyenLop(int idSinhVien, int idLopHoc) {
        SinhVien sv = em.find(SinhVien.class, idSinhVien);
        LopHoc lopHoc = em.find(LopHoc.class, idLopHoc);
        sv.setLopHoc(lopHoc);
        
        em.merge(sv);
    }
}
