package bean;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import model.Category;

@Stateless
@LocalBean
public class CategoryBean {

    @PersistenceContext
    private EntityManager em;

    public List<Category> findAll() {
        return em.createQuery("select a from Category a")
                .getResultList();
    }
}
