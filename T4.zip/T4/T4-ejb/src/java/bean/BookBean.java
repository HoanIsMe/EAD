package bean;

import dto.BookDTO;
import dto.NewBookDTO;
import dto.SimpleBookDTO;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import model.Book;
import model.Category;

@Stateless
@LocalBean
public class BookBean {

    @PersistenceContext
    private EntityManager em;

    public List<BookDTO> findAll() {
        // I
//        List<BookDTO> results = new ArrayList<>();
//        List<Book> list = em.createQuery("select a from Book a")
//                .getResultList();
//        for (Book bo : list) {
//            BookDTO dto = new BookDTO();
//            
//            dto.setIsbn(bo.getIsbn());
//            dto.setName(bo.getName());
//            dto.setPrice(bo.getPrice());
//            dto.setAuthor(bo.getAuthor());
//            dto.setCategoryName(bo.getCategory().getName());
//            
//            results.add(dto);
//        }
//        return results;
//
// II
//        return em.createQuery("select a from Book a", Book.class)
//                .getResultList()
//                .stream()
//                .map(bo -> {
//                    BookDTO dto = new BookDTO();
//
//                    dto.setIsbn(bo.getIsbn());
//                    dto.setName(bo.getName());
//                    dto.setPrice(bo.getPrice());
//                    dto.setAuthor(bo.getAuthor());
//                    dto.setCategoryName(bo.getCategory().getName());
//
//                    return dto;
//                }).collect(Collectors.toList());
//
        // III
        return em.createQuery("select a from Book a", Book.class)
                .getResultList()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    private BookDTO toDTO(Book bo) {
        BookDTO dto = new BookDTO();

        dto.setIsbn(bo.getIsbn());
        dto.setName(bo.getName());
        dto.setPrice(bo.getPrice());
        dto.setAuthor(bo.getAuthor());
        dto.setCategoryName(bo.getCategory().getName());

        return dto;
    }

    public void addNew(NewBookDTO dto) {
        Book bo = new Book();

        bo.setIsbn(dto.getIsbn());
        bo.setPrice(dto.getPrice());
        bo.setName(dto.getName());
        bo.setAuthor(dto.getAuthor());

        Category cat = em.find(Category.class, dto.getCategoryId());
        bo.setCategory(cat);

        em.persist(bo);
    }

    public void update(String isbn, Integer categoryId) {
        Book bo = em.find(Book.class, isbn);
        Category cat = em.find(Category.class, categoryId);

        bo.setCategory(cat);

        em.merge(bo);
    }

    public SimpleBookDTO findByIsbn(String isbn) {
        Book bo = em.find(Book.class, isbn);
        
        SimpleBookDTO dto = new SimpleBookDTO();
        dto.setName(bo.getName());
        dto.setCategoryId(bo.getCategory().getId());
        
        return dto;
    }

    public void xoa(String isbn) {
        Book bo = em.find(Book.class, isbn);
        em.remove(bo);
    }
}
