/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package session;

import dto.BookDTO;
import dto.NewBookDTO;
import dto.SimpleBookDTO;
import java.util.List;
import java.util.Queue;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.inject.Inject;
import javax.jms.Destination;
import javax.jms.JMSContext;
import javax.jms.TextMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import model.Book;
import model.Category;

/**
 *
 * @author PC
 */
@Stateless
@LocalBean
public class bookSession {

    @PersistenceContext
    private EntityManager em;
    
    @Inject
    private JMSContext contect;
    
    @Resource(mappedName = "java:/queue/MyQueue")
    private Destination queue;
    
    public void sendMassage(String name){
        TextMessage msg= contect.createTextMessage("Hello " + name);
        contect.createProducer().send( queue,msg);
    }

    public List<BookDTO> findAll() {
        // I
//        List<BookDTO> results = new ArrayList<>();
//        List<Book> list = em.createQuery("select a from Book a")
//                .getResultList();
//        for (Book bo : list) {
//            BookDTO dto = new BookDTO();
//            
//            dto.setIsbn(bo.getIsbn());
//            dto.setName(bo.getName());
//            dto.setPrice(bo.getPrice());
//            dto.setAuthor(bo.getAuthor());
//            dto.setCategoryName(bo.getCategory().getName());
//            
//            results.add(dto);
//        }
//        return results;
//
// II
//        return em.createQuery("select a from Book a", Book.class)
//                .getResultList()
//                .stream()
//                .map(bo -> {
//                    BookDTO dto = new BookDTO();
//
//                    dto.setIsbn(bo.getIsbn());
//                    dto.setName(bo.getName());
//                    dto.setPrice(bo.getPrice());
//                    dto.setAuthor(bo.getAuthor());
//                    dto.setCategoryName(bo.getCategory().getName());
//
//                    return dto;
//                }).collect(Collectors.toList());
//
        // III
        return em.createQuery("select a from Book a", Book.class)
                .getResultList()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    private BookDTO toDTO(Book bo) {
        BookDTO dto = new BookDTO();

        dto.setIsbn(bo.getIsbn());
        dto.setName(bo.getName());
        dto.setPrice(bo.getPrice());
        dto.setAuthor(bo.getAuthor());
        dto.setCategoryName(bo.getCategory().getName());

        return dto;
    }

    public void addNew(NewBookDTO dto) {
        Book bo = new Book();

        bo.setIsbn(dto.getIsbn());
        bo.setPrice(dto.getPrice());
        bo.setName(dto.getName());
        bo.setAuthor(dto.getAuthor());

        Category cat = em.find(Category.class, dto.getCategoryId());
        bo.setCategory(cat);

        em.persist(bo);
    }

    public void update(String isbn, Integer categoryId) {
        Book bo = em.find(Book.class, isbn);
        Category cat = em.find(Category.class, categoryId);

        bo.setCategory(cat);

        em.merge(bo);
    }

    public SimpleBookDTO findByIsbn(String isbn) {
        Book bo = em.find(Book.class, isbn);
        
        SimpleBookDTO dto = new SimpleBookDTO();
        dto.setName(bo.getName());
        dto.setCategoryId(bo.getCategory().getId());
        
        return dto;
    }

    public void xoa(String isbn) {
        Book bo = em.find(Book.class, isbn);
        em.remove(bo);
    }

    
}
